<?php require "lib.php";

    echo $_POST['id'];
    echo " / ";
    echo $_POST['password'];

?>