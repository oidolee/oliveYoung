<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="login_db.php" method="POST">
        <label for="id">아이디:<input type="text" name="id" id="id"></label>
        <label for="password">비밀번호:<input type="password" name="password" id="password"></label>
        <button type="submit">로그인</button>
    </form>
    <a href="join.php">회원가입</a>
</body>
</html>